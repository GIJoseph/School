<?php
	$something = $_POST["practice"];
    print '<p>'. $something. '</p>';

/*
	if(count($something) != 0){
		foreach($yes as $something){
			print '<p>'.$yes.'</p>';
		}
	}
	else{
		print '<p> something </p>';
	}
    */
?>