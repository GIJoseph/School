<?php
	$services_file = file("services.txt");
	$i = 0;$count = 0;
	$services_title = array();
	$description = array();
	$selection = array();
	while ($i < count($services_file)){
		$services_title[] = $services_file[$i];
		$description[] = $services_file[$i + 1];
		$i = $i + 2;
	};
	foreach($services_title as $i => $title)
	{
		if(isset($_POST["option".$i])){
			$selection[] = $_POST["option".$i];
			$count = $count + 1;
		}
		else{
			$selection[] = "off";
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Fish Creek Animal Hospital Services</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="fishcreek.css">
</head>
<body>
  <div id="wrapper">
	<header>
		<h1>Fish Creek Animal Hospital - Services</h1>
	</header>
	<nav>
		<a href="index.html">Home</a> &nbsp;
		<a href="services.html">Services</a> &nbsp;
		<a href="askvet.html">Ask the Vet</a> &nbsp;
		<a href="contact.html">Contact</a>
	</nav>
	<main>
		<p>
			Basic <?php print $count; ?> services
		</p>
		<ul>
		<?php
			foreach($services_title as $i => $title){
				if($selection[$i] == 'on'){
					print '<li><span class="category">'. $title . '</span><br>' . $description[$i] . '</li>';
				}
			}
		?>
		</ul>
	</main>
	<hr>
	<footer>
		1-800-555-5555<br>
		1242 Grassy Lane<br>
		Fish Creek, WI 55534<br>
		<a href="mailto:webmaster@fishcreek.com">webmaster@fishcreek.com</a>
	</footer>
  </div>
</body>
</html>