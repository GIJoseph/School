<?php
	$services_file = file("fishcreek/services.txt");
	$services_title = array();
	$i = 0;
	while ($i < count($services_file)){
		$services_title[] = $services_file[$i];
		$i = $i + 2;
	}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title> Homework 3 </title>
	</head>
	<body>
		<form action="fishcreek/services.php" method="post">
			<p>
				Which  services would you like to include?
			</p>
			<ul>
			<?php
				foreach($services_title as $i=>$title_name){
					print '<li><input type="checkbox" checked="checked" name="option'. $i .'">'. $title_name .'</li>';
				}
			?>
			</ul>
			<p>What is your username?</p>
			<input type="textfield" name="username">
			<p>What is your email address?</p>
			<input type="textfield" name="email"><br>
			<?php
				
				
			?>
			<input type="submit">
		</form>
	</body>
</html>