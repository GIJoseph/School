//
//  ViewController.swift
//  Exam2B
//
//  Created by McVicker, Steven A on 10/30/17.
//  Copyright © 2017 McVicker, Steven A. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    private let nameLabel: UILabel
    private let classLabel: UILabel
    
    let button1: UIButton
    
    
    init() {
        
        let screenSize: CGSize = UIScreen.main.bounds.size
        let centerX: CGFloat = screenSize.width / 2
        let centerY: CGFloat = screenSize.height / 2
        
        
        nameLabel = UILabel()
        nameLabel.text = "Steven McVicker"
        classLabel = UILabel()
        classLabel.text = "CS 354"
        button1 = UIButton(type: UIButtonType.custom)
        button1.setTitle("Begin", for: UIControlState.normal)
        button1.isUserInteractionEnabled = true
        
        nameLabel.frame = CGRect(x: screenSize.width - 150, y: 10 , width: 150, height: 50)
        nameLabel.textAlignment = NSTextAlignment.right
        classLabel.frame = CGRect(x: screenSize.width - 150, y: 40 , width: 150, height: 50)
        classLabel.textAlignment = NSTextAlignment.right
       
        
          super.init(nibName: nil, bundle: nil)
        
        
        self.view.addSubview(nameLabel)
        self.view.addSubview(classLabel)
        
        button1.frame = CGRect(x: centerX-32, y: centerY-32, width: 64, height: 64)
        button1.addTarget(self, action: #selector(ViewController.buttonPressed), for: UIControlEvents.touchUpInside)
        
        self.view.addSubview(button1)
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    @objc func buttonPressed() {
        NSLog("Button was pressed")
        let svc: SecondaryViewController = SecondaryViewController()
        svc.view.backgroundColor = UIColor.gray
        self.present(svc, animated: true) { () -> Void in
            NSLog("Secondary view controller presented...")
        }
       
    }
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

