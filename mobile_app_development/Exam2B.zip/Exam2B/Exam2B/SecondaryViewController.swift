//
//  SecondaryViewController.swift
//  Exam2B
//
//  Created by McVicker, Steven A on 10/30/17.
//  Copyright © 2017 McVicker, Steven A. All rights reserved.
//

import UIKit

class SecondaryViewController: UIViewController {
    var picStamp5: UIImageView
    var picStamp5Flipped: UIImageView
    
     override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?){
        
        let screenSize: CGSize = UIScreen.main.bounds.size
        let centerX: CGFloat = screenSize.width / 2
        let centerY: CGFloat = screenSize.height / 2
        
        picStamp5 = UIImageView()
        picStamp5Flipped = UIImageView()
       
        super.init(nibName: nil, bundle: nil)
        
        picStamp5.image = UIImage(named: "stamp5")
        picStamp5.frame = CGRect(x: centerX - 25, y:screenSize.height / 4 , width: 50, height: 50)
        picStamp5Flipped.image = UIImage(named: "stamp5flipped")
        picStamp5Flipped.frame = CGRect(x: centerX - 25, y: ((screenSize.height / 4) * 3), width: 50, height: 50)
        
         picStamp5.isUserInteractionEnabled = true
        
        self.view.addSubview(picStamp5)
        self.view.addSubview(picStamp5Flipped)
        
         picStamp5.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(SecondaryViewController.moveStamp(_:))))
        
        
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func moveStamp(_ recognizer: UIPanGestureRecognizer) {
        print("in handlePan")
        let translation: CGPoint = recognizer.translation(in: self.view)
        
        
        if (recognizer.view!.center.y < (UIScreen.main.bounds.height/2))
        {
            recognizer.view?.center = CGPoint(x: recognizer.view!.center.x + translation.x, y: recognizer.view!.center.y + translation.y)
            
          
            
            recognizer.setTranslation(CGPoint(x: 0, y: 0), in: self.view)
          
        }
          picStamp5Flipped.center = CGPoint(x: picStamp5Flipped.center.x + translation.x, y: picStamp5Flipped.center.x - translation.y)
        
        if recognizer.state == UIGestureRecognizerState.began {
            print("began touch in handlePan")
            
        
            
        }
        else if recognizer.state == UIGestureRecognizerState.ended {
            print("ended touch in handlePan")
        }
    }

 
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
