//
//  ViewController.swift
//  Exam2B
//
//  Created by Goergen, Joseph M on 10/30/17.
//  Copyright © 2017 Goergen, Joseph M. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let name: UILabel
    let className: UILabel
    let begin: UIButton
    let evaporate: UIButton
    
    init(){
        name = UILabel()
        className = UILabel()
        begin = UIButton(type: UIButtonType.custom)
        evaporate = UIButton(type: UIButtonType.custom)
        
        super.init(nibName: nil, bundle: nil)
        
        name.text = "Joseph Goergen"
        name.frame = CGRect(x: UIScreen.main.bounds.width - 150, y: 0, width: 150, height: 50)
        self.view.addSubview(name)
        
        className.text = "CS 345"
        className.frame = CGRect(x: UIScreen.main.bounds.width - 150, y: 20, width: 150, height: 50)
        self.view.addSubview(className)
        
        self.view.backgroundColor = UIColor.red
        
        begin.setTitle("Hello", for: .normal)
        begin.frame = CGRect(x: 0, y: 100, width: 100, height: 100)
        //begin.backgroundColor = UIColor.white
        begin.addTarget(self, action: #selector(ViewController.displayPictures), for: UIControlEvents.touchUpInside)
        
        evaporate.setTitle("Evaporate", for: .normal)
        evaporate.frame = CGRect(x: 0, y: 400, width: 100, height: 100)
        evaporate.addTarget(self, action: #selector(ViewController.displayPictures), for: UIControlEvents.touchUpInside)
        
        self.view.addSubview(begin)
    }
    func getTooCenter(){
        
    }
    
    @objc func displayPictures(_ recognizer: UITapGestureRecognizer){
        let svc: secondaryViewController = secondaryViewController()
        self.present(svc, animated: true) { () -> Void in
            NSLog("Secondary view controller presented...")
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

