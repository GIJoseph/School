//
//  secondaryViewController.swift
//  Exam2B
//
//  Created by Goergen, Joseph M on 10/30/17.
//  Copyright © 2017 Goergen, Joseph M. All rights reserved.
//

import UIKit

class secondaryViewController: UIViewController {
    let pic1: touchablePicture
    let pic2: UIImageView
    init(){
        pic2 = UIImageView()
        pic1 = touchablePicture(pic2)
        super.init(nibName: nil, bundle: nil)
        
        pic1.image = UIImage(named:"stamp5.png")
        pic2.image = UIImage(named:"stamp5flipped.png")
        
        pic1.frame = CGRect(x: (UIScreen.main.bounds.width / 2) - 25, y: UIScreen.main.bounds.height * (1/4) - 25, width: 50, height: 50)
        pic2.frame = CGRect(x: (UIScreen.main.bounds.width / 2) - 25, y: UIScreen.main.bounds.height * (3/4) - 25, width: 50, height: 50)
        
        self.view.backgroundColor = UIColor.gray
        pic1.isUserInteractionEnabled = true
        
        self.view.addSubview(pic1)
        self.view.addSubview(pic2)
    }
 
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func handleTap(_ recognizer: UITapGestureRecognizer) {
        self.presentingViewController?.dismiss(animated: true, completion: { () -> Void in
            NSLog("Secondary view controller dismissed...")
        })
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
