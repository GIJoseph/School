//
//  TouchableLabel.swift
//  MyFirstProject
//
//  Created by Goergen, Joseph M on 9/11/17.
//  Copyright © 2017 Goergen, Joseph M. All rights reserved.
//

import UIKit

class touchablePicture: UIImageView{
    var offset: CGPoint
    var isSynced: Bool
    let otherPic: UIImageView
    init(_ oPic: UIImageView){
        otherPic = oPic
        offset = CGPoint(x: 0, y: 0)
        isSynced = false
        super.init(frame: CGRect(x:0, y:0, width:0, height:0))
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first!
        let touchedView: UIView = touch.view!
        offset = touch.location(in: touchedView)
        offset.x = touchedView.frame.size.width/2 - offset.x
        offset.y = touchedView.frame.size.height/2 - offset.y
        
        self.superview?.bringSubview(toFront: self)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first!
        let touchedView: UIView = touch.view!
        var location: CGPoint = touch.location(in: touchedView.superview)
        if(location.y < (UIScreen.main.bounds.height / 2))
        {
            location.y += offset.y
            //otherPic.frame = CGRect(x: location.x, y: UIScreen.main.bounds.height * (3/4) - 25, width: 50, height: 50)
            touchedView.center.y = location.y
        }
        location.x += offset.x
        otherPic.frame = CGRect(x: location.x, y: UIScreen.main.bounds.height - location.y, width: 50, height: 50)
        touchedView.center.x = location.x
    }
    
    func moveTooCenter(){
        UIView.animate(withDuration: 5, animations: {() -> Void in
            self.center = CGPoint(x: UIScreen.main.bounds.width / 2 - 25, y: UIScreen.main.bounds.height / 2 - 25)
        }, completion: {(Bool) -> Void in
            /*UIView.animate(withDuration: 5, animations: {() -> Void in
                
            }, completion: {(Bool) -> Void in
                
            })*/
        })
    }
    
    
}

