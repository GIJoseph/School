//
//  ViewController.swift
//  PickerView
//
//  Created by Tim Gegg-Harrison on 2/16/15.
//  Copyright (c) 2015 Tim Gegg-Harrison. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    let streetNames: [String] = ["Broadway", "Wabasha", "Huff", "Sanborn", "King", "Howard", "Main"]
    var directions: [String] = []
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        let pickerView: UIPickerView = UIPickerView(frame: CGRect.zero)
        pickerView.delegate = self
        pickerView.dataSource = self
        self.view.addSubview(pickerView)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return (component == 0) ? streetNames.count : directions.count
    }
    
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        return (component == 0) ? 200.0 : 100.0
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 40.0
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return (component == 0) ? streetNames[row] : directions[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 0 {
            let street: String = streetNames[pickerView.selectedRow(inComponent: 0)]
            if street == "Huff" || street == "Main" {
                directions = ["North", "South"]
            }
            else {
                directions = ["East", "West"]
            }
            pickerView.reloadComponent(1)
        }
        NSLog("Selected row \(row) in component \(component)...")
    }
}

