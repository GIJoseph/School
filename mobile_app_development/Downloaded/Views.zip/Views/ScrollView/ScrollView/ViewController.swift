//
//  ViewController.swift
//  ScrollView
//
//  Created by Tim Gegg-Harrison on 2/16/15.
//  Copyright (c) 2015 Tim Gegg-Harrison. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate {

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        let screenSize: CGSize = UIScreen.main.bounds.size
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        let picture: UIImageView = UIImageView(image: UIImage(named: "picture.jpg"))
        picture.tag = 100
        let scrollView: UIScrollView = UIScrollView(frame: UIScreen.main.bounds)
        scrollView.delegate = self
        scrollView.minimumZoomScale = 0.25
        scrollView.maximumZoomScale = 2.0
        scrollView.bounces = false
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.contentSize = picture.frame.size
        scrollView.contentOffset = CGPoint(x: (picture.frame.size.width-screenSize.width)/2,y: (picture.frame.size.height-screenSize.height)/2)
        scrollView.addSubview(picture)
        self.view = scrollView
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return self.view.viewWithTag(100)
    }
}

