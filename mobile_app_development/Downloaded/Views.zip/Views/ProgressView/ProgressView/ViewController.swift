//
//  ViewController.swift
//  ProgressView
//
//  Created by Tim Gegg-Harrison on 2/16/15.
//  Copyright (c) 2015 Tim Gegg-Harrison. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var progressBar: UIProgressView
    var activityIndicator: UIActivityIndicatorView
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        let screenSize: CGSize = UIScreen.main.bounds.size
        let centerX: CGFloat = screenSize.width / 2
        let centerY: CGFloat = screenSize.height / 2
        progressBar = UIProgressView(frame: CGRect(x: centerX-100, y: centerY-80, width: 200, height: 40))
        activityIndicator = UIActivityIndicatorView(frame: CGRect(x: centerX-40, y: centerY+40, width: 40, height: 40))
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        progressBar.progressViewStyle = UIProgressViewStyle.default
        progressBar.progress = 0.0
        activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
        activityIndicator.startAnimating()
        self.view.addSubview(progressBar)
        self.view.addSubview(activityIndicator)
        Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(ViewController.updateProgress(_:)), userInfo: nil, repeats: true)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func updateProgress(_ timer: Timer) {
        progressBar.progress += 0.1
        if progressBar.progress >= 1.0 {
            timer.invalidate()
            activityIndicator.stopAnimating()
        }
    }
}

