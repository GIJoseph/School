//
//  ViewController.swift
//  TextField
//
//  Created by GeggHarrison, Timothy S on 10/4/16.
//  Copyright © 2016 Tim Gegg-Harrison. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    private let label1: UILabel
    private let label2: UILabel
    private let label3: UILabel
    private let button1: UIButton
    private let textField1: UITextField
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        label1 = UILabel()
        label2 = UILabel()
        label3 = UILabel()
        button1 = UIButton(type: UIButtonType.custom)
        textField1 = UITextField()
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        let screenSize: CGSize = UIScreen.main.bounds.size
        let centerX: CGFloat = screenSize.width / 2
        let centerY: CGFloat = screenSize.height / 2
        label1.text = "Top Label"
        label1.backgroundColor = UIColor.red
        label1.textColor = UIColor.gray
        label1.textAlignment = NSTextAlignment.center
        label1.frame = CGRect(x: centerX-75, y: 100, width: 150, height: 50)
        self.view.addSubview(label1)
        label2.text = "Bottom Label"
        label2.backgroundColor = UIColor.gray
        label2.textColor = UIColor.red
        label2.textAlignment = NSTextAlignment.center
        label2.frame = CGRect(x: centerX-75, y: screenSize.height-150, width: 150, height: 50)
        self.view.addSubview(label2)
        label3.text = "Portrait"
        label3.backgroundColor = UIColor.clear
        label3.textColor = UIColor.black
        label3.textAlignment = NSTextAlignment.center
        label3.frame = CGRect(x: centerX-100, y: centerY-25, width: 200, height: 50)
        self.view.addSubview(label3)
        
        button1.frame = CGRect(x: centerX-32, y: UIScreen.main.bounds.size.height-74, width: 64, height: 64)
        button1.setImage(#imageLiteral(resourceName: "play.png"), for: UIControlState.normal)
        button1.addTarget(self, action: #selector(ViewController.buttonPressed), for: UIControlEvents.touchUpInside)
        self.view.addSubview(button1)
        
        textField1.frame = CGRect(x: centerX-100, y: centerY-125, width: 200, height: 50)
        textField1.textColor = UIColor.black
        textField1.font = UIFont.systemFont(ofSize: 17.0)
        textField1.placeholder = "<enter new top label>"
        textField1.backgroundColor = UIColor.white
        textField1.borderStyle = UITextBorderStyle.bezel
        textField1.keyboardType = UIKeyboardType.default
        textField1.returnKeyType = UIReturnKeyType.done
        textField1.clearButtonMode = UITextFieldViewMode.always
        textField1.delegate = self
        self.view.addSubview(textField1)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var shouldAutorotate : Bool {
        return true
    }
    
    override var supportedInterfaceOrientations : UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.all
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        let centerX: CGFloat = size.width / 2
        let centerY: CGFloat = size.height / 2
        label1.frame = CGRect(x: centerX-75, y: 100, width: 150, height: 50)
        label2.frame = CGRect(x: centerX-75, y: size.height-150, width: 150, height: 50)
        label3.frame = CGRect(x: centerX-100, y: centerY-25, width: 200, height: 50)
        if size.width > size.height {
            label3.text = "Landscape"
        }
        else {
            label3.text = "Portrait"
        }
        button1.frame = CGRect(x: centerX-32, y: size.height-74, width: 64, height: 64)
        textField1.frame = CGRect(x: centerX-100, y: centerY-125, width: 200, height: 50)
    }
    
    func buttonPressed() {
        NSLog("Button was pressed")
        
        let alert: UIAlertController
            = UIAlertController(title: "Color Switch", message:
                "Do you want to change label and switch the colors?", preferredStyle:
                UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "Yes", style:
            UIAlertActionStyle.default, handler:
            {(action: UIAlertAction!) -> Void in
                if self.label1.backgroundColor == UIColor.red {
                    self.label1.backgroundColor = UIColor.gray
                    self.label1.textColor = UIColor.red
                    self.label2.backgroundColor = UIColor.red
                    self.label2.textColor = UIColor.gray
                }
                else {
                    self.label1.backgroundColor = UIColor.red
                    self.label1.textColor = UIColor.gray
                    self.label2.backgroundColor = UIColor.gray
                    self.label2.textColor = UIColor.red
                }
                self.label2.text = alert.textFields?[0].text
        }))
        alert.addAction(UIAlertAction(title: "No", style:
            UIAlertActionStyle.default, handler:
            {(action: UIAlertAction!) -> Void in
                
        }))
        alert.addTextField(configurationHandler: {(t: UITextField) -> Void in
            t.placeholder = "<enter new bottom label>"})
        
        self.present(alert, animated: true, completion:
            {() -> Void in
                
        })
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField1 == textField {
            label1.text = textField1.text
            if textField1.text == "Hide" {
                textField1.resignFirstResponder()   // hide keyboard
                textField1.isHidden = true          // hide textfield
            }
        }
        return true
    }

}

