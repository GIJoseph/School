//
//  ViewController.swift
//  ModalViewController
//
//  Created by GeggHarrison, Timothy S on 9/24/17.
//  Copyright © 2017 Tim Gegg-Harrison. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var label: UILabel
    
    init(string: String) {
        label = UILabel()
        super.init(nibName: nil, bundle: nil)
        let screenSize: CGSize = UIScreen.main.bounds.size
        let centerX: CGFloat = screenSize.width / 2
        let centerY: CGFloat = screenSize.height / 2
        label.text = string
        label.backgroundColor = UIColor.clear
        label.textColor = UIColor.black
        label.textAlignment = NSTextAlignment.center
        label.frame = CGRect(x: centerX-100, y: centerY-25, width: 200, height: 50)
        label.isUserInteractionEnabled = true
        label.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(ViewController.handleTap(_:))))
        self.view.addSubview(label)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func handleTap(_ recognizer: UITapGestureRecognizer) {
        let svc: SecondaryViewController = SecondaryViewController(string: "Secondary View Controller")
        svc.view.backgroundColor = UIColor.purple
        self.present(svc, animated: true) { () -> Void in
            NSLog("Secondary view controller presented...")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

