//
//  SecondaryViewController.swift
//  Exam3B
//
//  Created by Goergen, Joseph M on 11/27/17.
//  Copyright © 2017 Goergen, Joseph M. All rights reserved.
//

import UIKit

class SecondaryViewController: UIViewController {
    
    var purple: UIImageView
    var numTapped: Int
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?){
        
        purple = UIImageView()
        numTapped = 0
        super.init(nibName: nil, bundle: nil)
        self.view.backgroundColor = UIColor.white
        
        purple.image = UIImage(named: "purple.jpg")
        purple.frame = CGRect(x: 0, y: 0, width: 48, height: 48)
        purple.center = CGPoint(x: UIScreen.main.bounds.size.width / 2, y: UIScreen.main.bounds.size.height / 2)
        purple.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(SecondaryViewController.purpleTapped(_:))))
        purple.isUserInteractionEnabled = true
        
        self.view.addSubview(purple)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func purpleTapped(_ recognizer: UITapGestureRecognizer){
        if(recognizer.state == .ended){
            self.numTapped += 1
            let size = self.purple.frame.size.width * 0.25
            UIView.animate(withDuration: 3, animations: {() -> Void in
                self.purple.frame = CGRect(x: self.purple.frame.origin.x-(size/2), y: self.purple.frame.origin.y-(size/2), width:1.25*self.purple.frame.size.width , height: 1.25*self.purple.frame.size.height)
            }, completion: {(Bool) -> Void in
                
            })
            if (self.numTapped == 3){
                let alert: UIAlertController
                    = UIAlertController(title: "Tapped 3 Times", message:
                        "Do you want to go back to other screen?", preferredStyle:
                        UIAlertControllerStyle.alert)
                
                alert.addAction(UIAlertAction(title: "Yes", style:
                    UIAlertActionStyle.default, handler:
                    {(action: UIAlertAction!) -> Void in
                        self.presentingViewController?.dismiss(animated: true, completion: { () -> Void in
                            NSLog("Dismissing stats page")
                        })
                }))
                alert.addAction(UIAlertAction(title: "No", style:
                    UIAlertActionStyle.default, handler:
                    {(action: UIAlertAction!) -> Void in
                        self.purple.frame = CGRect(x: 0, y: 0, width: 48, height: 48)
                        self.purple.center = CGPoint(x: UIScreen.main.bounds.size.width / 2, y: UIScreen.main.bounds.size.height / 2)
                        self.numTapped = 0
                }))
                self.present(alert, animated: true, completion:
                    {() -> Void in
                        
                })
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
