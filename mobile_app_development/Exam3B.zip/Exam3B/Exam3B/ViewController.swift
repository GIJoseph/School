//
//  ViewController.swift
//  Exam3B
//
//  Created by Goergen, Joseph M on 11/27/17.
//  Copyright © 2017 Goergen, Joseph M. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let name: UILabel
    let classLabel: UILabel
    var multi: UIImageView
    
    let screenSize: CGSize = UIScreen.main.bounds.size
    let centerX: CGFloat
    let centerY: CGFloat
    let nextButton: UILabel
    
    init(){
        centerX = screenSize.width / 2
        centerY = screenSize.height / 2
        
        
        name = UILabel()
        classLabel = UILabel()
        multi = UIImageView()
        nextButton = UILabel()
        super.init(nibName: nil, bundle: nil)
        
        name.text = "Joe"
        name.frame = CGRect(x: screenSize.width - 150, y: 10 , width: 150, height: 50)
        name.textAlignment = NSTextAlignment.right
        
        classLabel.text = "CS 345"
        classLabel.frame = CGRect(x: screenSize.width - 150, y: 40 , width: 150, height: 50)
        classLabel.textAlignment = NSTextAlignment.right
        
        multi.image = UIImage(named: "multi.jpg")
        multi.frame = CGRect(x: 0, y: 0, width: 48, height: 48)
        multi.center = CGPoint(x: centerX, y: screenSize.height - 104)
        multi.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(ViewController.multiTapped(_:))))
        multi.isUserInteractionEnabled = true
        
        nextButton.frame = CGRect(x: screenSize.width - 50, y: screenSize.height - 50, width: 50, height: 50)
        nextButton.text = "Next"
        nextButton.textAlignment = NSTextAlignment.center
        nextButton.isUserInteractionEnabled = true
        nextButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(ViewController.nextButtonTapped(_:))))
        
        self.view.addSubview(name)
        self.view.addSubview(classLabel)
        self.view.addSubview(multi)
        self.view.addSubview(nextButton)
        self.view.backgroundColor = UIColor.white
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //invisibleCover.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(HangManViewController.restartTapped(_:))))

    @objc func multiTapped(_ recognizer: UITapGestureRecognizer){
        if(recognizer.state == .ended){
            UIView.animate(withDuration: 3, animations: {() -> Void in
                self.multi.center = CGPoint(x: self.centerX, y: 24)
            }, completion: {(Bool) -> Void in
               
            })
        }
    }
    @objc func nextButtonTapped(_ recognizer: UITapGestureRecognizer){
        if(recognizer.state == .ended){
            NSLog("Button was pressed")
            let svc: SecondaryViewController = SecondaryViewController()
            self.present(svc, animated: true) { () -> Void in
                NSLog("Secondary view controller presented...")
            }
        }
    }
    

}

