//
//  ViewController.swift
//  EightPuzzle
//
//  Created by Tim Gegg-Harrison on 3/30/15.
//  Copyright (c) 2015 TiNi Apps LLC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let fileManager: FileManager = FileManager.default
    let filePath: String = "\(NSHomeDirectory())/tmp/eightpuzzle.txt"
    let DIMENSION = 3
    let SWAPCOUNT = 10
    let LEFTOFFSET: CGFloat = 10.0
    var TOPOFFSET: CGFloat = 0.0
    var TILESIZE: CGFloat = 0.0
    let OPEN: Int = 0
    
    let reset: UIButton
    
    private var puzzle: PuzzleState = PuzzleState()
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        NSLog("Absolute path for Home Directory: \(NSHomeDirectory())")
        
        let dirPath: String = "\(NSHomeDirectory())/tmp/directory"
        var isDir: ObjCBool = true
        if fileManager.fileExists(atPath: dirPath, isDirectory: &isDir) {
            if isDir.boolValue {
                NSLog("file exists and is a directory")
            }
            else {
                NSLog("file exists and is not a directory")
            }
        }
        else {
            NSLog("file does not exist")
            do {
                try fileManager.createDirectory(atPath: dirPath, withIntermediateDirectories: true, attributes: nil)
            }
            catch {
                NSLog("directory not created")
            }
        }
        
        reset = UIButton(type: UIButtonType.roundedRect)
        
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        
        self.view.backgroundColor = UIColor.lightText

        TILESIZE = (UIScreen.main.bounds.size.width - 2*LEFTOFFSET) / CGFloat(DIMENSION)
        TOPOFFSET = (UIScreen.main.bounds.size.height - CGFloat(DIMENSION)*(150/107)*TILESIZE) / 2
        
        self.layoutPuzzle()
        
        reset.frame = CGRect(x: UIScreen.main.bounds.size.width/2-50, y: UIScreen.main.bounds.size.height-60, width: 100, height: 40)
        reset.setTitle("RESET", for: UIControlState.normal)
        reset.backgroundColor = UIColor.white
        reset.addTarget(self, action: #selector(ViewController.resetPuzzle), for: UIControlEvents.touchUpInside)
        self.view.addSubview(reset)
        self.undoManager?.levelsOfUndo = 10
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func resetPuzzle() {
        for tile in self.view.subviews {
            if tile != reset {
                tile.removeFromSuperview()
            }
        }
        self.deletePuzzleStateFile()
        self.layoutPuzzle()
    }

    func slideTile(_ recognizer: UIPanGestureRecognizer) {
        let tile: TileView = recognizer.view as! TileView
        let (i,j): (Int, Int) = puzzle.board[tile.index]
        let (openI,openJ): (Int, Int) = puzzle.board[OPEN]
        let translation: CGPoint = recognizer.translation(in: self.view)
        if (i == (openI - 1) && j == openJ && translation.x > 0)
            || (i == (openI + 1) && j == openJ && translation.x < 0)
            || (i == openI && j == (openJ - 1) && translation.y > 0)
            || (i == openI && j == (openJ + 1) && translation.y < 0) {
            self.moveTile(tile)
        }
    }
    
    private func moveTile(_ tile: TileView) {
        let (openI,openJ): (Int, Int) = puzzle.board[OPEN]
        tile.center = CGPoint(x: (CGFloat(openI) + 0.5)*self.TILESIZE+self.LEFTOFFSET, y: (CGFloat(openJ) + 0.5)*(150/107)*self.TILESIZE+self.TOPOFFSET)
        self.swapTiles(index1: self.OPEN, index2: tile.index)
        self.undoManager?.registerUndo(withTarget: tile, handler: { (t: TileView) in
            self.moveTile(t)
        })
        self.undoManager?.setActionName("move")
        self.savePuzzleState()
    }
    
    private func swapTiles(index1: Int, index2: Int) {
        let temp = puzzle.board[index1]
        self.puzzle.board[index1] = self.puzzle.board[index2]
        self.puzzle.board[index2] = temp
    }
    
    private func layoutPuzzle() {
        var tile: TileView
        var i,j: Int
        self.restorePuzzleState()
        for k in 1...DIMENSION*DIMENSION-1 {
            (i,j) = puzzle.board[k]
            tile = TileView(frame: CGRect(x: CGFloat(i)*TILESIZE+LEFTOFFSET, y: CGFloat(j)*(150/107)*TILESIZE+TOPOFFSET, width: TILESIZE, height: (150/107)*TILESIZE))
            tile.image = UIImage(named: "card\(k).png")
            tile.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(ViewController.slideTile(_:))))
            tile.index = k
            tile.isUserInteractionEnabled = true
            self.view.addSubview(tile)
        }
    }
    
    private func savePuzzleState() {
        let data: Data? = NSKeyedArchiver.archivedData(withRootObject: puzzle)
        if fileManager.createFile(atPath: filePath,
                                  contents: data,
                                  attributes: nil) {
            NSLog("File successfully created")
        }
        else {
            NSLog("Error creating file")
        }
        let dirEnumerator: FileManager.DirectoryEnumerator = fileManager.enumerator(atPath: NSHomeDirectory())!
        var currentPath: String? = dirEnumerator.nextObject() as! String?
        while currentPath != nil {
            NSLog(currentPath!)
            currentPath = dirEnumerator.nextObject() as! String?
        }
    }
 
    private func restorePuzzleState() {
        let data: Data? = fileManager.contents(atPath: filePath)
        if data != nil {
            NSLog("Retrieving data")
            puzzle = (NSKeyedUnarchiver.unarchiveObject(with: data!) as! PuzzleState)
        }
        else {
            NSLog("No data available")
            puzzle = PuzzleState()
            puzzle.board.insert((0,0), at: 0)
            var i,j: Int
            for k in 1...DIMENSION*DIMENSION-1 {
                i = k % DIMENSION
                j = k / DIMENSION
                puzzle.board.insert((i,j), at: k)
            }
            for _ in 1...SWAPCOUNT {
                i = Int(arc4random_uniform(UInt32(DIMENSION*DIMENSION)))
                j = Int(arc4random_uniform(UInt32(DIMENSION*DIMENSION)))
                self.swapTiles(index1: i, index2: j)
            }
        }
    }
    
    private func deletePuzzleStateFile() {
        do {
            try fileManager.removeItem(atPath: filePath)
        }
        catch {
            
        }
        let dirEnumerator: FileManager.DirectoryEnumerator = fileManager.enumerator(atPath: NSHomeDirectory())!
        var currentPath: String? = dirEnumerator.nextObject() as! String?
        while currentPath != nil {
            NSLog(currentPath!)
            currentPath = dirEnumerator.nextObject() as! String?
        }
    }
 
    override var canBecomeFirstResponder : Bool {
        return true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.becomeFirstResponder()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        self.resignFirstResponder()
    }
}

