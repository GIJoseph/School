//
//  PuzzleState.swift
//  EightPuzzle
//
//  Created by Tim Gegg-Harrison on 3/30/15.
//  Copyright (c) 2015 TiNi Apps LLC. All rights reserved.
//

import UIKit

let TNBoardI: String = "BoardI"
let TNBoardJ: String = "BoardJ"

class PuzzleState: NSObject, NSCoding {
   
    var board: [(Int,Int)]

    override init() {
        board = [(Int,Int)]()
        super.init()
    }
    
    required init(coder aDecoder: NSCoder) {
        let boardI: [Int] = aDecoder.decodeObject(forKey: TNBoardI) as! [Int]
        let boardJ: [Int] = aDecoder.decodeObject(forKey: TNBoardJ) as! [Int]
        board = [(Int,Int)]()
        for k in 0...boardI.count-1 {
            board.insert((boardI[k], boardJ[k]), at: k)
        }
    }
    
    func encode(with aCoder: NSCoder) {
        var boardI: [Int] = [Int]()
        var boardJ: [Int] = [Int]()
        for k in 0...board.count-1 {
            let (i,j) = board[k]
            boardI.insert(i, at: k)
            boardJ.insert(j, at: k)
        }
        aCoder.encode(boardI, forKey: TNBoardI)
        aCoder.encode(boardJ, forKey: TNBoardJ)
    }
}
