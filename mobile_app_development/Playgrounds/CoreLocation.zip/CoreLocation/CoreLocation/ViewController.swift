//
//  ViewController.swift
//  CoreLocation1
//
//  Created by Tim Gegg-Harrison on 3/23/15.
//  Copyright (c) 2015 TiNi Apps LLC. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {

    let manager = CLLocationManager()
    let geocoder = CLGeocoder()
    var currentLatitude: CLLocationDegrees
    var currentLongitude: CLLocationDegrees
    var currentLatitudeLabel: UILabel
    var currentLongitudeLabel: UILabel
    var currentAddressLabel: UILabel
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    init() {
        let screenSize: CGSize = UIScreen.main.bounds.size
        currentLatitudeLabel = UILabel(frame:CGRect(x: 60,y: 130,width: 150,height: 30))
        currentLongitudeLabel = UILabel(frame:CGRect(x: 60,y: 210,width: 150,height: 30))
        currentAddressLabel = UILabel(frame:CGRect(x: 60,y: 320,width: 250,height: 90))
        currentLatitude = 37.33233141
        currentLongitude = -120.03121860
        super.init(nibName: nil, bundle: nil)
        self.view.backgroundColor = UIColor.lightText
        currentLatitudeLabel.backgroundColor = UIColor.clear
        currentLongitudeLabel.backgroundColor = UIColor.clear
        currentAddressLabel.backgroundColor = UIColor.clear
        currentAddressLabel.numberOfLines = 0
        self.view.addSubview(currentLatitudeLabel)
        self.view.addSubview(currentLongitudeLabel)
        self.view.addSubview(currentAddressLabel)
        
        manager.requestWhenInUseAuthorization()
        manager.distanceFilter = kCLDistanceFilterNone
        manager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        manager.delegate = self
        manager.startUpdatingLocation()
        
        var label: UILabel = UILabel(frame:CGRect(x: 30,y: 100,width: 150,height: 30))
        label.text = "Current Latitude:"
        self.view.addSubview(label)
        label = UILabel(frame:CGRect(x: 30,y: 180,width: 150,height: 30))
        label.text = "Current Longitude:"
        self.view.addSubview(label)
        label = UILabel(frame:CGRect(x: 30,y: 290,width: 150,height: 30))
        label.text = "Current Address:"
        self.view.addSubview(label)
        
        label = UILabel(frame:CGRect(x: screenSize.width-100, y: screenSize.height-50, width: 100, height: 50))
        label.text = "Map It!"
        label.backgroundColor = UIColor.red
        label.textColor = UIColor.white
        label.textAlignment = NSTextAlignment.center
        label.isUserInteractionEnabled = true
        label.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(ViewController.handleTap(_:))))
        self.view.addSubview(label)        
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func handleTap(_ recognizer: UITapGestureRecognizer) {
        let mvc: MapViewController = MapViewController(location: CLLocationCoordinate2D(latitude: self.currentLatitude, longitude: self.currentLongitude))
        self.present(mvc, animated: true) { () -> Void in
            NSLog("Map view controller presented...")
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        NSLog("Location updated...")
        let location = locations[locations.count-1]
        self.currentLatitude = location.coordinate.latitude
        self.currentLongitude = location.coordinate.longitude
        self.currentLatitudeLabel.text = "\(self.currentLatitude)"
        self.currentLongitudeLabel.text = "\(self.currentLongitude)"
        manager.stopUpdatingLocation()
        geocoder.reverseGeocodeLocation(location, completionHandler: { (placemarks: [CLPlacemark]?, error: Error?) -> Void in
            NSLog("Geocoder obtained ...")
            if error == nil  {
                if placemarks != nil && placemarks!.count > 0 {
                    let placemark: CLPlacemark = placemarks![0]
                    self.currentAddressLabel.text = "\(placemark.subThoroughfare!) \(placemark.thoroughfare!)\n\(placemark.locality!), \(placemark.administrativeArea!) \(placemark.postalCode!)\n\(placemark.country!)"
                }
                else {
                    NSLog("No placemark data...")
                }
            }
            else {
                NSLog("Geocoder error: \(error!)")
            }
        })
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        NSLog("Location error: \(error)")
    }

}

