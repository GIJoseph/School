//
//  MapViewController.swift
//  CoreLocation1
//
//  Created by Tim Gegg-Harrison on 3/23/15.
//  Copyright (c) 2015 TiNi Apps LLC. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

let HOME = "Current longitude and latitude"
let METERS_PER_MILE = 1609.344

class MapViewController: UIViewController, MKMapViewDelegate {

    let map = MKMapView()
    var location: CLLocationCoordinate2D
    
    init(location: CLLocationCoordinate2D) {
        let screenSize: CGSize = UIScreen.main.bounds.size
        self.location = location
        super.init(nibName: nil, bundle: nil)
        map.delegate = self
        map.frame = UIScreen.main.bounds
        map.region = MKCoordinateRegionMakeWithDistance(location, 100*METERS_PER_MILE, 100*METERS_PER_MILE)
        map.addAnnotation(MapPoint(coordinate: location, title: HOME, subtitle: "\(location.longitude), \(location.latitude)"))
        for i in 1...5 {
            let latDelta: Double = 1.5*Double(arc4random())/Double(RAND_MAX)
            let longDelta: Double = Double(arc4random())/Double(RAND_MAX)
            map.addAnnotation(MapPoint(coordinate: CLLocationCoordinate2D(latitude: location.latitude + latDelta, longitude: location.longitude + longDelta), title: "Pin \(i)'s longitude and latitude", subtitle: "\(location.longitude + latDelta), \(location.latitude + longDelta)"))
        }
        self.view = map
        
        let label: UILabel = UILabel()
        label.text = "Go Back"
        label.backgroundColor = UIColor.red
        label.textColor = UIColor.white
        label.textAlignment = NSTextAlignment.center
        label.frame = CGRect(x: screenSize.width-100, y: screenSize.height-50, width: 100, height: 50)
        label.isUserInteractionEnabled = true
        label.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(MapViewController.handleTap(_:))))
        self.view.addSubview(label)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let annotationView: MKPinAnnotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "MyPin")
        if annotation.title! == HOME {
            annotationView.pinTintColor = MKPinAnnotationView.greenPinColor()
        }
        else {
            annotationView.pinTintColor = MKPinAnnotationView.redPinColor()
        }
        annotationView.annotation = annotation
        annotationView.canShowCallout = true
        return annotationView
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        let annotationView: MKPinAnnotationView = view as! MKPinAnnotationView
        annotationView.pinTintColor = MKPinAnnotationView.purplePinColor()
    }
    
    func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView) {
        let annotationView: MKPinAnnotationView = view as! MKPinAnnotationView
        if annotationView.annotation?.title! == HOME {
            annotationView.pinTintColor = MKPinAnnotationView.greenPinColor()
        }
        else {
            annotationView.pinTintColor = MKPinAnnotationView.redPinColor()
        }
    }

    func handleTap(_ recognizer: UITapGestureRecognizer) {
        self.presentingViewController?.dismiss(animated: true, completion: { () -> Void in
            NSLog("Map view controller dismissed...")
        })
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
