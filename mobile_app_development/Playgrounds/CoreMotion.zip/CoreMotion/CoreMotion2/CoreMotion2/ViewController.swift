//
//  ViewController.swift
//  CoreMotion2
//
//  Created by Tim Gegg-Harrison on 3/17/15.
//  Copyright (c) 2015 TiNi Apps LLC. All rights reserved.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {
    
    var ball: UIImageView
    let manager = CMMotionManager()
    let stepFactor: CGFloat = 15.0
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        let screenSize: CGSize = UIScreen.main.bounds.size
        let centerX: CGFloat = screenSize.width / 2
        let centerY: CGFloat = screenSize.height / 2
        ball = UIImageView(frame: CGRect(x: centerX-25, y: centerY-25, width: 50, height: 50))
        ball.image = UIImage(named: "basketball.jpg")
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        self.view.addSubview(ball)
        /*
        //accelerometer
        if manager.isAccelerometerAvailable {
            manager.accelerometerUpdateInterval = 0.01
            manager.startAccelerometerUpdates(to: OperationQueue.main, withHandler: {
                (data: CMAccelerometerData?, error: Error?) in
                if data != nil {
                    let movetoX: CGFloat = self.ball.frame.origin.x + (CGFloat(data!.acceleration.x) * self.stepFactor)
                    let maxX: CGFloat = self.view.frame.size.width - self.ball.frame.size.width
                    let movetoY: CGFloat = self.ball.frame.origin.y - (CGFloat(data!.acceleration.y) * self.stepFactor)
                    let maxY: CGFloat = self.view.frame.size.height - self.ball.frame.size.height
                    if (movetoX > 0 && movetoX < maxX) {
                        self.ball.frame.origin.x += (CGFloat(data!.acceleration.x) * self.stepFactor)
                    }
                    if (movetoY > 0 && movetoY < maxY) {
                        self.ball.frame.origin.y -= (CGFloat(data!.acceleration.y) * self.stepFactor)
                    }
                }
            })
        */
        //device motion
        if manager.isDeviceMotionAvailable {
            manager.deviceMotionUpdateInterval = 0.01
            manager.startDeviceMotionUpdates(to: OperationQueue.main, withHandler: {
                (data: CMDeviceMotion?, error: Error?) in
                if data != nil {
                    let movetoX: CGFloat = self.ball.frame.origin.x + (CGFloat(data!.gravity.x) * self.stepFactor)
                    let maxX: CGFloat = self.view.frame.size.width - self.ball.frame.size.width
                    let movetoY: CGFloat = self.ball.frame.origin.y - (CGFloat(data!.gravity.y) * self.stepFactor)
                    let maxY: CGFloat = self.view.frame.size.height - self.ball.frame.size.height
                    if (movetoX > 0 && movetoX < maxX) {
                        self.ball.frame.origin.x += (CGFloat(data!.gravity.x) * self.stepFactor)
                    }
                    if (movetoY > 0 && movetoY < maxY) {
                        self.ball.frame.origin.y -= (CGFloat(data!.gravity.y) * self.stepFactor)
                    }
                }
            })
            
        }
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
