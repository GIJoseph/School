//
//  ViewController.swift
//  CoreMotion1
//
//  Created by Tim Gegg-Harrison on 3/17/15.
//  Copyright (c) 2015 TiNi Apps LLC. All rights reserved.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {
    
    var ball: UIImageView
    let manager = CMMotionManager()
    
    init() {
        let screenSize: CGSize = UIScreen.main.bounds.size
        let centerX: CGFloat = screenSize.width / 2
        let centerY: CGFloat = screenSize.height / 2
        ball = UIImageView(frame: CGRect(x: centerX-100, y: centerY-100, width: 200, height: 200))
        ball.image = UIImage(named: "basketball.jpg")
        super.init(nibName: nil, bundle: nil)
        self.view.addSubview(ball)
        /*
        //accelerometer
        if manager.isAccelerometerAvailable {
            manager.accelerometerUpdateInterval = 0.01
            manager.startAccelerometerUpdates(to: OperationQueue.main, withHandler: {
                (data: CMAccelerometerData?, error: Error?) in
                NSLog("accelerometer updated...")
                if data != nil {
                    let rotation = atan2(data!.acceleration.x, data!.acceleration.y) - M_PI
                    self.ball.transform = CGAffineTransform(rotationAngle: CGFloat(rotation))
                }
            })
        }
        */

        //device motion
        if manager.isDeviceMotionAvailable {
            manager.deviceMotionUpdateInterval = 0.01
            manager.startDeviceMotionUpdates(to: OperationQueue.main, withHandler: {
                (data: CMDeviceMotion?, error: Error?) in
                NSLog("device motion updated...")
                if data != nil {
                    let rotation = atan2(data!.gravity.x, data!.gravity.y) - Double.pi
                    self.ball.transform = CGAffineTransform(rotationAngle: CGFloat(rotation))
                }
            })
        }
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
