//
//  ViewController.swift
//  MotionEvent
//
//  Created by Tim Gegg-Harrison on 3/17/15.
//  Copyright (c) 2015 TiNi Apps LLC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var heart: Bool
    var card: View
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    init() {
        heart = true
        let screenSize: CGSize = UIScreen.main.bounds.size
        let centerX: CGFloat = screenSize.width / 2
        let centerY: CGFloat = screenSize.height / 2
        card = View(frame: CGRect(x: centerX-37.5, y: centerY-53.5, width: 75, height: 107))
        card.image = UIImage(named: "aceOfHearts")
        super.init(nibName: nil, bundle: nil)
        self.view.addSubview(card)
        card.isUserInteractionEnabled = true
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func motionBegan(_ motion: UIEventSubtype, with event: UIEvent?) {
        card.transform = CGAffineTransform(rotationAngle: ((arc4random_uniform(2)==0) ? -1.0 : 1.0)*(CGFloat(arc4random_uniform(15)))*CGFloat(Double.pi)/180.0)
    }
    
    override func motionEnded(_ motion: UIEventSubtype, with event: UIEvent?) {
        if heart {
            card.image = UIImage(named: "aceOfSpades")
        }
        else {
            card.image = UIImage(named: "aceOfHearts")
        }
        heart = !heart
    }

}
