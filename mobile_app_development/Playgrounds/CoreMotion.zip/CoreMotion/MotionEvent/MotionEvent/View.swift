//
//  View.swift
//  MotionEvent
//
//  Created by Tim Gegg-Harrison on 3/17/15.
//  Copyright (c) 2015 TiNi Apps LLC. All rights reserved.
//

import UIKit

class View: UIImageView {

    var offset: CGPoint
    
    override init(frame: CGRect) {
        offset = CGPoint(x: 0, y: 0)
        super.init(frame: frame)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch: UITouch = touches.first!
        let touchedView: UIView = touch.view!
        offset = touch.location(in: touchedView)
        offset.x = touchedView.frame.size.width/2 - offset.x
        offset.y = touchedView.frame.size.height/2 - offset.y
        self.superview?.bringSubview(toFront: self)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch: UITouch = touches.first!
        let touchedView: UIView = touch.view!
        var location: CGPoint = touch.location(in: touchedView.superview)
        location.x += offset.x
        location.y += offset.y
        touchedView.center = location
    }

}
