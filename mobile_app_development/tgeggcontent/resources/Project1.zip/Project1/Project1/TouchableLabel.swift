//
//  TouchableLabel.swift
//  Project1
//
//  Created by GeggHarrison, Timothy S on 9/10/17.
//  Copyright © 2017 Tim Gegg-Harrison. All rights reserved.
//

import UIKit

class TouchableLabel: UILabel {

    var offset: CGPoint

    init() {
        offset = CGPoint(x: 0, y: 0)
        super.init(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
        self.isUserInteractionEnabled = true
    }
    
    override init(frame: CGRect) {
        offset = CGPoint(x: 0, y: 0)
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("in touchesBegan")
        let touch = touches.first!
        let touchedView: UIView = touch.view!
        offset = touch.location(in: touchedView)
        offset.x = touchedView.frame.size.width/2 - offset.x
        offset.y = touchedView.frame.size.height/2 - offset.y
        self.superview?.bringSubview(toFront: self)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("in touchesMoved")
        let touch = touches.first!
        let touchedView: UIView = touch.view!
        var location: CGPoint = touch.location(in: touchedView.superview)
        location.x += offset.x
        location.y += offset.y
        touchedView.center = location
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        print("in touchesEnded")
    }
    
}
