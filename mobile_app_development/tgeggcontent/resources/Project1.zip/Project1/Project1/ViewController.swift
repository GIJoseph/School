//
//  ViewController.swift
//  Project1
//
//  Created by GeggHarrison, Timothy S on 8/30/17.
//  Copyright © 2017 Tim Gegg-Harrison. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    private let label1: TouchableLabel
    private let label2: UILabel
    private let label3: UILabel
    private let image1: UIImageView
    
    init() {
        label1 = TouchableLabel()
        label2 = UILabel()
        label3 = UILabel()
        image1 = UIImageView()
        super.init(nibName: nil, bundle: nil)
        let screenSize: CGSize = UIScreen.main.bounds.size
        let centerX: CGFloat = screenSize.width / 2
        let centerY: CGFloat = screenSize.height / 2
        label1.isHidden = false
        label1.text = "Top Label"
        label1.backgroundColor = UIColor.red
        label1.textColor = UIColor.gray
        label1.textAlignment = NSTextAlignment.center
        label1.frame = CGRect(x: centerX-75, y: 100, width: 150, height: 50)
        self.view.addSubview(label1)
        label2.text = "Bottom Label"
        label2.backgroundColor = UIColor.gray
        label2.textColor = UIColor.red
        label2.textAlignment = NSTextAlignment.center
        label2.frame = CGRect(x: centerX-75, y: screenSize.height-150, width: 150, height: 50)
        label2.isUserInteractionEnabled = true
        label2.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(ViewController.handlePan(_:))))
        self.view.addSubview(label2)
        label3.text = "Portrait"
        label3.backgroundColor = UIColor.clear
        label3.textColor = UIColor.black
        label3.textAlignment = NSTextAlignment.center
        label3.frame = CGRect(x: centerX-100, y: centerY-25, width: 200, height: 50)
        self.view.addSubview(label3)
        image1.image = UIImage(named: "hearts.png")
        image1.frame = CGRect(x: centerX-37.5, y: centerY-157, width: 75, height: 107)
        self.view.addSubview(image1)
        print("init completed")
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func handlePan(_ recognizer: UIPanGestureRecognizer) {
        print("in handlePan")
        let translation: CGPoint = recognizer.translation(in: self.view)
        recognizer.view?.center = CGPoint(x: recognizer.view!.center.x + translation.x, y: recognizer.view!.center.y + translation.y)
        recognizer.setTranslation(CGPoint(x: 0, y: 0), in: self.view)
        if recognizer.state == UIGestureRecognizerState.began {
            print("began touch in handlePan")
        }
        else if recognizer.state == UIGestureRecognizerState.ended {
            print("ended touch in handlePan")
        }
    }
    
    override var shouldAutorotate : Bool {
        return true
    }
    
    override var supportedInterfaceOrientations : UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.all
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        let centerX: CGFloat = size.width / 2
        let centerY: CGFloat = size.height / 2
        label1.frame = CGRect(x: centerX-75, y: 100, width: 150, height: 50)
        label2.frame = CGRect(x: centerX-75, y: size.height-150, width: 150, height: 50)
        label3.frame = CGRect(x: centerX-100, y: centerY-25, width: 200, height: 50)
        image1.frame = CGRect(x: centerX-37.5, y: centerY-157, width: 75, height: 107)
        image1.image = UIImage(named: "spades.png")
        if size.width > size.height {
            label3.text = "Landscape"
        }
        else {
            label3.text = "Portrait"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

