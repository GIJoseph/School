//
//  Course.swift
//  TableView
//
//  Created by Tim Gegg-Harrison on 4/2/15.
//  Copyright (c) 2015 TiNi Apps LLC. All rights reserved.
//

import UIKit

class Course: NSObject {
    var number: String
    var title: String
    var topics: String
    
    init(number: String, title: String, topics: String) {
        self.number = number
        self.title = title
        self.topics = topics
    }
}
