//
//  ViewController.swift
//  TableView
//
//  Created by Tim Gegg-Harrison on 4/2/15.
//  Copyright (c) 2015 TiNi Apps LLC. All rights reserved.
//

import UIKit

let VIEW_HEIGHT: CGFloat = 460
let IPAD_WIDTH: CGFloat = 400
let IPHONE_WIDTH: CGFloat = 300
let COURSETYPECELL: String = "CourseTypeCell"
let IS_IPAD: Bool = UIScreen.main.bounds.size.height == 1024          // 748x1024

var courses: [(String,[Course])] = [
    ("Core courses",[Course(number: "CS 101", title: "Exploring Creative Computing", topics: "This course is aimed at students with little or no programming experience. Students will learn how to think methodically and how to solve problems effectively with computers through activity-based learning. Students will learn some of the 'Big Ideas' of computing and experiment with activities such as visual programming, creating mobile apps and controlling robotics. Meets GOAL 4. Prerequisite: Qualifying score on the mathematics placement exam or MATH 050 - Intermediate Algebra. Grade only. Offered every semester."),
        Course(number: "CS 234", title: "Algorithms and Problem Solving I", topics: "An introduction to the major concepts of algorithm design and problem solving. Emphasis is on algorithm development, analysis, and refinement. Programming strategies and elements of programming also are covered. Various practical applications of problem-solving are demonstrated. Includes formal labs. Prerequisites: Qualifying score on the math placement test or MATH 050 - Intermediate Algebra."),
        Course(number: "CS 250", title: "Algorithms and Problem Solving II", topics: "A continuation of the problem solving and programming concepts introduced in CS 234 - Algorithms and Problem-Solving I. Applies the basic principles of software engineering to more complex problems. Topics include recursive problem solving, searching, sorting, and dynamic structures. Prerequisites: CS 234 - Algorithms and Problem-Solving I and MATH 120 - Precalculus."),
        Course(number: "CS 275", title: "Mathematical Foundations of Algorithms", topics: "The formal study of the mathematical foundations of algorithms. This course provides students with an algorithm-based introduction to discrete mathematical structures and their application to computer science. Topics include sets, relations, graphs, proof techniques, induction, recursive definitions, and recurrence relations. Applications include the correctness and complexity of algorithms. Prerequisites: CS 234 - Algorithms and Problem-Solving I and MATH 120 - Precalculus, or instructor’s permission."),
        Course(number: "CS 313", title: "Networking and Telecommunications", topics: "This course studies telecommunications and computer networks. It begins by discussing data communications, computer interfaces, transmission media, and error detection and correction. Wide area, metropolitan, and local area networks are studied in the context of the International Standards Organization/OSI Model. Emphasis is placed on the physical, data link, network, transport, and session layers. Prerequisites: CS 250 - Algorithms and Problem-Solving II and one 300-level CS course."),
        Course(number: "CS 341", title: "Data Structures", topics: "A detailed study of more advanced data structures and algorithms, including concepts and techniques of design efficiency and complexity of algorithms and their lower bounds. Topics include search trees, hash functions, string searching, disjoint sets, internal and external sorting, graphs and graph algorithms, and different algorithm design technique. Prerequisites: CS 250 - Algorithms and Problem-Solving II and CS 275 - Mathematical Foundations of Algorithms."),
        Course(number: "CS 375", title: "Computer Systems", topics: "This course is an overview of the hardware and software of computer systems. Topics include computer organization and computer architecture, data representation, assembly language, memory systems, operating systems, networking and security, run-time environments, and advanced topics such as RISC vs. CISC, non von Neumann architectures, and Java virtual machine. Prerequisites: CS 250 - Algorithms and Problem-Solving II."),
        Course(number: "CS 385", title: "Applied Data Management Systems", topics: "A study of basic Database Management Systems (DBMS) concepts. Topics include DBMS Models-Relational and object-oriented; study of query languages; study of exiting DBMS; and data integrity, recovery, and concurrency control. Prerequisites: CS 250 - Algorithms and Problem-Solving II and ENG 111 - College Reading and Writing."),
        Course(number: "CS 410", title: "Software Engineering", topics: "The course deals with the current trends of software engineering principles and techniques for methodical construction of large, complex software-intensive systems. It follows the software life cycle from the requirement, specification, design, and testing phases. Topics include software process, project management, quality assurance, configuration management, formal specification techniques, design methodologies, testing and validation techniques, and object-oriented methodologies. Students are involved in a team project utilizing software engineering principles. Prerequisites: CS 341 - Data Structures and ENG 111 - College Reading and Writing. "),
        Course(number: "CS 471", title: "Object Oriented Design and Development", topics: "This course will cover fundamental topics in object-oriented analysis, design, and development. An object-oriented design methodology and tool will be introduced and used. The course will use an object oriented development environment/language. Advanced features of object-oriented languages will be covered. Students will be required to investigate issues in object-oriented systems and their implementation. Prerequisites: CS 341 - Data Structures and CMST 191 - Introduction to Public Speaking."),
        Course(number: "STAT 210", title: "Statistics", topics: "First course in statistics for students with a strong mathematics background.  Meets GOAL 4. Prerequisites:  MATH 140 - Applied Calculus or MATH 212 - Calculus I.")]),
    ("Required courses",[Course(number: "CS 415", title: "Principles of Programming Languages", topics: ""),
        Course(number: "CS 435", title: "Theory of Computation", topics: "")]),
    ("Elective courses",[Course(number: "CS 345", title: "Mobile Application Development", topics: ""),
        Course(number: "CS 445", title: "Artificial Intelligence", topics: "")])
]

class ViewController: UITableViewController {

    private var courseView: UITableView
    private var editButton: UIButton

    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init() {
        editButton = UIButton(type: UIButtonType.custom)
        let screenSize: CGSize = UIScreen.main.bounds.size
        if (IS_IPAD) {
            courseView = UITableView(frame: CGRect(x: (screenSize.width-IPAD_WIDTH)/2, y: (screenSize.height-VIEW_HEIGHT)/2, width: IPAD_WIDTH, height: VIEW_HEIGHT), style: UITableViewStyle.plain)
        }
        else {
            courseView = UITableView(frame: CGRect(x: (screenSize.width-IPHONE_WIDTH)/2, y: (screenSize.height-VIEW_HEIGHT)/2, width: IPHONE_WIDTH, height: VIEW_HEIGHT), style: UITableViewStyle.plain)
        }
        super.init(style: UITableViewStyle.plain)
        courseView.dataSource = self
        courseView.delegate = self
        if (IS_IPAD) {
            self.view = UIView(frame: CGRect(x: (screenSize.width-IPAD_WIDTH)/2, y: (screenSize.height-VIEW_HEIGHT)/2, width: IPAD_WIDTH, height: VIEW_HEIGHT))
        }
        else {
            self.view = UIView(frame: CGRect(x: (screenSize.width-IPHONE_WIDTH)/2, y: (screenSize.height-VIEW_HEIGHT)/2, width: IPHONE_WIDTH, height: VIEW_HEIGHT))
        }
        self.view.backgroundColor = UIColor(red: 0.83984375, green: 0.85546875, blue: 0.84375, alpha: 1.0)
        self.view.addSubview(courseView)
        
        editButton.frame = CGRect(x: UIScreen.main.bounds.width-90, y: 20, width: 90, height: 90)
        editButton.setTitle("Edit", for: UIControlState.normal)
        editButton.addTarget(self, action: #selector(ViewController.editTable), for: UIControlEvents.touchUpInside)
        self.view.addSubview(editButton)
    }
    
    func editTable() {
        courseView.setEditing(!courseView.isEditing, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // UITableViewDataSource
    override func numberOfSections(in tableView: UITableView) -> Int {
        return courses.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let (_,A) = courses[section]
        return A.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let CELL_HEIGHT: CGFloat = 50
        var cell = tableView.dequeueReusableCell(withIdentifier: COURSETYPECELL) as UITableViewCell?
        if cell == nil {
            cell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: COURSETYPECELL)
        }
        var courseEntry: UITextView
        if IS_IPAD {
            courseEntry = UITextView(frame: CGRect(x: 0, y: 0, width: IPAD_WIDTH, height: CELL_HEIGHT))
        }
        else {
            courseEntry = UITextView(frame: CGRect(x: 0, y: 0, width: IPHONE_WIDTH, height: CELL_HEIGHT))
        }
        courseEntry.tag = 1
        if indexPath.row % 2 == 0 {
            courseEntry.backgroundColor = UIColor.lightGray
        }
        else {
            courseEntry.backgroundColor = UIColor.gray
        }
        courseEntry.font = UIFont.boldSystemFont(ofSize: IS_IPAD ? 14.0 : 13.0)
        cell!.contentView.addSubview(courseEntry)
        let (_,A) = courses[indexPath.section]
        let course: Course = A[indexPath.row]
        courseEntry.text = course.number + "\n" + course.title
        courseEntry.isUserInteractionEnabled = false
        return cell!
    }
    
    // UITableViewDelegate
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let (_,A) = courses[indexPath.section]
        let alert: UIAlertController = UIAlertController(title:"\(A[indexPath.row].number): \(A[indexPath.row].title)", message:A[indexPath.row].topics, preferredStyle:UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style:
            UIAlertActionStyle.default, handler:
            {(action: UIAlertAction!) -> Void in
                // nothing to do
        }))
        tableView.deselectRow(at: indexPath, animated: false)
        self.present(alert, animated: true, completion:
            {() -> Void in
                // nothing to do
        })
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 60
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let result: CGSize = UIScreen.main.bounds.size
        let label: UILabel = UILabel(frame: CGRect(x: 0, y: 40, width: result.width, height: 20))
        label.backgroundColor = UIColor.white
        let (S,_) = courses[section]
        label.text = S
        label.font = UIFont.boldSystemFont(ofSize: IS_IPAD ? 22.0 : 18.0)
        return label
    }
    
    override func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return UITableViewCellEditingStyle.delete
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        switch editingStyle {
        case UITableViewCellEditingStyle.delete:
            courses[indexPath.section].1.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: UITableViewRowAnimation.top)
        default:
            break
        }
    }
}
