//
//  ViewController.swift
//  Animation
//
//  Created by GeggHarrison, Timothy S on 10/4/16.
//  Copyright © 2016 Tim Gegg-Harrison. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    private let bounce: UIButton
    private let inflate: UIButton
    private let basketball: UIImageView
    private let basketballSize: CGFloat = 50
    private let buttonSize: CGFloat = 64
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        bounce = UIButton(type: UIButtonType.custom)
        inflate = UIButton(type: UIButtonType.custom)
        basketball = UIImageView()
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        let screenSize: CGSize = UIScreen.main.bounds.size
        let centerX: CGFloat = screenSize.width / 2
        let centerY: CGFloat = screenSize.height / 2
        
        inflate.frame = CGRect(x: 0, y: 20, width: 90, height: 120)
        inflate.setImage(#imageLiteral(resourceName: "inflate.jpg"), for: UIControlState.normal)
        inflate.addTarget(self, action: #selector(ViewController.inflateBall), for: UIControlEvents.touchUpInside)
        self.view.addSubview(inflate)
        
        bounce.frame = CGRect(x: UIScreen.main.bounds.width-90, y: 20, width: 90, height: 90)
        bounce.setImage(#imageLiteral(resourceName: "bounce.png"), for: UIControlState.normal)
        bounce.addTarget(self, action: #selector(ViewController.bounceBall), for: UIControlEvents.touchUpInside)
        self.view.addSubview(bounce)
        
        basketball.frame = CGRect(x: centerX-(basketballSize/2), y: centerY-(basketballSize/2), width: basketballSize, height: basketballSize)
        basketball.image = UIImage(named: "basketball.jpg")
        self.view.addSubview(basketball)
        
        Timer.scheduledTimer(withTimeInterval: 5, repeats: true, block: {(timer: Timer) -> Void in
            let alert: UIAlertController
                = UIAlertController(title: "WARNING!!", message:
                    "Do you want future warnings?", preferredStyle:
                    UIAlertControllerStyle.alert)
            
            alert.addAction(UIAlertAction(title: "Yes", style:
                UIAlertActionStyle.default, handler:
                {(action: UIAlertAction!) -> Void in
                    
            }))
            alert.addAction(UIAlertAction(title: "No", style:
                UIAlertActionStyle.default, handler:
                {(action: UIAlertAction!) -> Void in
                  timer.invalidate()
            }))
            self.present(alert, animated: true, completion:
                {() -> Void in
                    
            })
        })
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var shouldAutorotate : Bool {
        return true
    }
    
    override var supportedInterfaceOrientations : UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.all
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        let centerX: CGFloat = size.width / 2
        bounce.frame = CGRect(x: centerX-(buttonSize/2), y: 20, width: buttonSize, height: buttonSize)
    }

    func inflateBall() {
        let size = 0.25*self.basketball.frame.size.width
        UIView.animate(withDuration: 4, animations: {
            () -> Void in
            self.basketball.frame = CGRect(x: self.basketball.frame.origin.x-(size/2), y: self.basketball.frame.origin.y-(size/2), width: 1.25*self.basketball.frame.size.width, height: 1.25*self.basketball.frame.size.height)
            }, completion: {
                (Bool) -> Void in
                
        })
    }

    func bounceBall() {
        let bottomPoint: CGPoint = CGPoint(x: basketball.center.x, y: (UIScreen.main.bounds.size.height-(self.basketball.bounds.width/2)))
        let topPoint: CGPoint = CGPoint(x: basketball.center.x, y: 0.75*basketball.center.y+0.25*bottomPoint.y)
        UIView.animate(withDuration: 2, animations: {
            () -> Void in
            self.basketball.center = bottomPoint
            }, completion: {
                (Bool) -> Void in
                UIView.animate(withDuration: 1.5, animations: {
                    () -> Void in
                    self.basketball.center = topPoint
                    }, completion: {
                        (Bool) -> Void in

                })
        })
    }

}

