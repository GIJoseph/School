//
//  CardView.swift
//  Disperse
//
//  Created by Tim Gegg-Harrison, Nicole Anderson on 7/27/16.
//  Copyright © 2016 TiNi Apps. All rights reserved.
//

import UIKit

class CardView: UIImageView {

    var suit: String
    var value: String
    var highlightColor: String
    var index: Int
    var rotation: CGFloat
    var location: CGPoint
    var removed: Bool
    
    init(suit: String, value: String) {
        self.suit = suit
        self.value = value
        highlightColor = "\0"
        index = 0
        rotation = 0
        location = CGPoint(x: 0, y: 0)
        removed = false
        super.init(frame: CGRect(x: 0, y: 0, width: (IS_IPAD ? 2*CARDWIDTH : CARDWIDTH), height: (IS_IPAD ? 2*CARDHEIGHT : CARDHEIGHT)))
        image = UIImage(named: "\(suit)-\(value)-150.png")
    }

    required init?(coder aDecoder: NSCoder) {
        //fatalError("init(coder:) has not been implemented")
        suit = aDecoder.decodeObject(forKey: "suit") as! String
        value = aDecoder.decodeObject(forKey: "value") as! String
        highlightColor = aDecoder.decodeObject(forKey: "highlightColor") as! String
        index = aDecoder.decodeInteger(forKey: "index")
        rotation = aDecoder.decodeObject(forKey: "rotation") as! CGFloat
        location = aDecoder.decodeCGPoint(forKey: "location")
        removed = aDecoder.decodeBool(forKey: "removed")
        super.init(coder: aDecoder)
        image = UIImage(named: "\(suit)-\(value)-150.png")
        self.frame = CGRect(x: 0, y: 0, width: (IS_IPAD ? 2*CARDWIDTH : CARDWIDTH), height: (IS_IPAD ? 2*CARDHEIGHT : CARDHEIGHT))
    }
    
    override func encode(with aCoder: NSCoder){
        aCoder.encode(suit, forKey: "suit")
        aCoder.encode(value, forKey: "value")
        aCoder.encode(highlightColor, forKey: "highlightColor")
        aCoder.encode(index, forKey: "index")
        aCoder.encode(rotation, forKey: "rotation")
        aCoder.encode(location, forKey: "location")
        aCoder.encode(removed, forKey: "removed")
    }
    
    func highlight(_ color: String) {
        highlightColor = color
        image = UIImage(named: "\(suit)-\(value)-150\(color).png")
    }
    
    func highlighted() -> Bool {
        return highlightColor != "\0"
    }
}
