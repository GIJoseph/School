//
//  Disperse4PileViewController.swift
//  Disperse
//
//  Created by Goergen, Joseph M on 11/18/17.
//  Copyright © 2017 Goergen, Joseph M. All rights reserved.
//

import UIKit

class Disperse4PileViewController: DisperseViewController {
    override func createBoard() {
        createCards()
        
        var clubPosition = CGPoint(x: BOARDWIDTH / 4, y: BOARDHEIGHT / 4)
        var spadesPosition = CGPoint(x: BOARDWIDTH * 0.75, y: BOARDHEIGHT / 4)
        var diamondsPosition = CGPoint(x: BOARDWIDTH / 4, y: BOARDHEIGHT * 0.75)
        var heartsPosition = CGPoint(x: BOARDWIDTH * 0.75, y: BOARDHEIGHT * 0.75)
        
        for card in game.board{
            if(card.suit == "c"){
                displayCard(card: card, index: card.index, rotation: 0, location: clubPosition)
                clubPosition = CGPoint(x: clubPosition.x + CARDTHICKNESS, y: clubPosition.y - CARDTHICKNESS)
            }
            else if(card.suit == "s"){
                displayCard(card: card, index: card.index, rotation: 0, location: spadesPosition)
                spadesPosition = CGPoint(x: spadesPosition.x + CARDTHICKNESS, y: spadesPosition.y - CARDTHICKNESS)
            }
            else if(card.suit == "d"){
                displayCard(card: card, index: card.index, rotation: 0, location: diamondsPosition)
                diamondsPosition = CGPoint(x: diamondsPosition.x + CARDTHICKNESS, y: diamondsPosition.y - CARDTHICKNESS)
            }
            else if(card.suit == "h"){
                displayCard(card: card, index: card.index, rotation: 0, location: heartsPosition)
                heartsPosition = CGPoint(x: heartsPosition.x + CARDTHICKNESS, y: heartsPosition.y - CARDTHICKNESS)
            }
            
        }
    }
}
