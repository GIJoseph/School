//
//  Disperse1Pile.swift
//  Disperse
//
//  Created by Goergen, Joseph M on 11/18/17.
//  Copyright © 2017 Goergen, Joseph M. All rights reserved.
//

import UIKit

class Disperse1PileViewController: DisperseViewController {
    override func displayCards() {
        var x,y: CGFloat
        x = BOARDWIDTH/2
        y = BOARDHEIGHT/2
        self.displayCard(card: game.board[0], index: 0, rotation: 0, location: CGPoint(x: x, y: y))
        for i in 1..<game.board.count {
            x += CARDTHICKNESS
            y -= CARDTHICKNESS
            self.displayCard(card: game.board[i], index: i, rotation: 0 , location: CGPoint(x: x, y: y))
        }
    }
}

