//
//  GameState.swift
//  Disperse
//
//  Created by Tim Gegg-Harrison, Nicole Anderson on 7/27/16.
//  Copyright © 2016 TiNi Apps. All rights reserved.
//

import UIKit

class GameState: NSObject, NSCoding {
    var board: [CardView]
    var blueTurn: Bool
    var user1Score: Int
    var user2Score: Int
    var cardsRemoved: [Int]
    
    override init() {
        board = [CardView]()
        blueTurn = true
        user1Score = 0
        user2Score = 0
        cardsRemoved = []
    }
    
    required init(coder aDecoder: NSCoder) {
        board = aDecoder.decodeObject(forKey: "board") as! [CardView]
        blueTurn = aDecoder.decodeBool(forKey: "blueTurn")
        user1Score = aDecoder.decodeInteger(forKey: "user1Score")
        user2Score = aDecoder.decodeInteger(forKey: "user2Score")
        cardsRemoved = aDecoder.decodeObject(forKey: "cardsRemoved") as! [Int]
        
    }
    
    func encode(with aCoder: NSCoder){
        aCoder.encode(board, forKey: "board")
        aCoder.encode(blueTurn, forKey: "blueTurn")
        aCoder.encode(user1Score, forKey: "user1Score")
        aCoder.encode(user2Score, forKey: "user2Score")
        aCoder.encode(cardsRemoved, forKey: "cardsRemoved")
    }
}
