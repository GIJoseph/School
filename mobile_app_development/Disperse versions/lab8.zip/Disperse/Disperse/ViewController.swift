//
//  ViewController.swift
//  Disperse
//
//  Created by Goergen, Joseph M on 8/23/17.
//  Copyright © 2017 Goergen, Joseph M. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.presentDisperseViewController()
    }
    func presentDisperseViewController() {
        let dvc: DisperseViewController = DisperseViewController()
        dvc.modalTransitionStyle = UIModalTransitionStyle.crossDissolve
        self.present(dvc, animated: true, completion: {
            () -> Void in
            dvc.enterNewGame()
        })
    }
    

}

