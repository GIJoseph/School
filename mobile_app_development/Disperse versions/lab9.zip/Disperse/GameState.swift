//
//  GameState.swift
//  Disperse
//
//  Created by Tim Gegg-Harrison, Nicole Anderson on 7/27/16.
//  Copyright © 2016 TiNi Apps. All rights reserved.
//

import UIKit

class GameState: NSObject, NSCoding {
    var board: [CardView]
    var blueTurn: Bool
    var user1Score: Int
    var user2Score: Int
    var cardsRemoved: [Int]
    var user1Name: String
    var user2Name: String
    var userNamesAreSet: Bool
    
    override init() {
        board = [CardView]()
        blueTurn = true
        user1Score = 0
        user2Score = 0
        cardsRemoved = []
        user1Name = "user1"
        user2Name = "user2"
        userNamesAreSet = false
    }
    
    required init(coder aDecoder: NSCoder) {
        board = aDecoder.decodeObject(forKey: "board") as! [CardView]
        blueTurn = aDecoder.decodeBool(forKey: "blueTurn")
        user1Score = aDecoder.decodeInteger(forKey: "user1Score")
        user2Score = aDecoder.decodeInteger(forKey: "user2Score")
        cardsRemoved = aDecoder.decodeObject(forKey: "cardsRemoved") as! [Int]
        user1Name = aDecoder.decodeObject(forKey: "user1Name") as! String
        user2Name = aDecoder.decodeObject(forKey: "user2Name") as! String
        userNamesAreSet = aDecoder.decodeBool(forKey: "userNamesAreSet")
    }
    
    func encode(with aCoder: NSCoder){
        aCoder.encode(board, forKey: "board")
        aCoder.encode(blueTurn, forKey: "blueTurn")
        aCoder.encode(user1Score, forKey: "user1Score")
        aCoder.encode(user2Score, forKey: "user2Score")
        aCoder.encode(cardsRemoved, forKey: "cardsRemoved")
        aCoder.encode(user1Name, forKey: "user1Name")
        aCoder.encode(user2Name, forKey: "user2Name")
        aCoder.encode(userNamesAreSet, forKey: "userNamesAreSet")
    }
}
