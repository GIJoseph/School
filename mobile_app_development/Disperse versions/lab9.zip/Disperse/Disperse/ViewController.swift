//
//  ViewController.swift
//  Disperse
//
//  Created by Goergen, Joseph M on 8/23/17.
//  Copyright © 2017 Goergen, Joseph M. All rights reserved.
//

import UIKit
let TNDisperse = "Disperse"
let games: [GameType] = [
    GameType(name: TNDisperse, rules: "Random    collection of cards - remove between one and four cards (up to one card of each suit) on your turn as long as each of the cards that you want to remove is not covered by another card.")
]
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //self.presentDisperseViewController()
        self.presentGameTypeViewController()
    }
    func presentDisperseViewController() {
        let dvc: DisperseViewController = DisperseViewController()
        dvc.modalTransitionStyle = UIModalTransitionStyle.crossDissolve
        self.present(dvc, animated: true, completion: {
            () -> Void in
            dvc.enterNewGame()
        })
    }
    func presentGameTypeViewController(){
        let gtvc: GameTypeViewController = GameTypeViewController(games)
        self.present(gtvc, animated: true, completion: {
            () -> Void in
        })
    }

}

