//
//  GameType.swift
//  Disperse
//
//  Created by Goergen, Joseph M on 11/15/17.
//  Copyright © 2017 Goergen, Joseph M. All rights reserved.
//

import UIKit

class GameType: NSObject {
    var name: String
    var rules: String
    
    init(name: String, rules: String) {
        self.name = name
        self.rules = rules
    }
}
