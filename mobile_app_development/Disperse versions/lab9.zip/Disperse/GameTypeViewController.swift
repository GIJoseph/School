//
//  GameTypeViewController.swift
//  Disperse
//
//  Created by Goergen, Joseph M on 11/15/17.
//  Copyright © 2017 Goergen, Joseph M. All rights reserved.
//

import UIKit

class GameTypeViewController: UITableViewController {
    let games:[GameType]
    let gameView: UITableView
    
    init(_ games: [GameType]){
        self.games = games
        gameView = UITableView(frame: CGRect(x: (0), y: (0), width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height), style: UITableViewStyle.plain)
        super.init(style: UITableViewStyle.plain)
        
        gameView.delegate = self
        gameView.dataSource = self
        //self.view.backgroundColor = UIColor(red: 0.83984375, green: 0.85546875, blue: 0.84375, alpha: 1.0)
        self.view.addSubview(gameView)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        //self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return games.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 1
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "gameTypeCell") as UITableViewCell?
        let CELL_HEIGHT: CGFloat = 50
        if cell == nil {
            cell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "gameTypeCell")
        }
        let gameEntry: UITextView = UITextView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: CELL_HEIGHT))
        // Configure the cell...
        gameEntry.tag = 1
        cell!.contentView.addSubview(gameEntry)
        gameEntry.text = games[indexPath.row].name + "\n" + games[indexPath.row].rules
        gameEntry.isUserInteractionEnabled = false
        return cell!
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let currentSelection = games[indexPath.row]
        let alert: UIAlertController = UIAlertController(title:"\(currentSelection.name):", message: currentSelection.rules, preferredStyle:UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style:
            UIAlertActionStyle.default, handler:
            {(action: UIAlertAction!) -> Void in
                // nothing to do
                if(currentSelection.name == "Disperse"){
                    let dvc: DisperseViewController = DisperseViewController()
                    dvc.modalTransitionStyle = UIModalTransitionStyle.crossDissolve
                    self.present(dvc, animated: true, completion: {
                        () -> Void in
                        dvc.enterNewGame()
                    })}
                //do more else if statements for other games
        }))
        tableView.deselectRow(at: indexPath, animated: false)
        self.present(alert, animated: true, completion:
            {() -> Void in
                // nothing to do
        })
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    

}
