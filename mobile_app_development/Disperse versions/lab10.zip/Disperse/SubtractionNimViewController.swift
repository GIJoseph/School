//
//  SubtractionNimViewController.swift
//  Disperse
//
//  Created by Goergen, Joseph M on 11/21/17.
//  Copyright © 2017 Goergen, Joseph M. All rights reserved.
//

import UIKit

class SubtractionNimViewController: Disperse1PileViewController {
    override func shuffleCards() {
        //doing nothing
    }
}
