//
//  ClassicNimViewController.swift
//  Disperse
//
//  Created by Goergen, Joseph M on 11/21/17.
//  Copyright © 2017 Goergen, Joseph M. All rights reserved.
//

import UIKit

class ClassicNimViewController: Disperse4PileViewController {
    override func updateSuitIndicatorForCard(card: CardView) {
        if card.suit == "s" {
            spades = false
            //spadesPic.removeFromSuperview()
            self.view.addSubview(spadesPic)
        }
        else if card.suit == "h" {
            hearts = false
            //heartsPic.removeFromSuperview()
            self.view.addSubview(heartsPic)
        }
        else if card.suit == "d" {
            diamonds = false
            //diamondsPic.removeFromSuperview()
            self.view.addSubview(diamondsPic)
        }
        else {
            clubs = false
            //clubsPic.removeFromSuperview()
            self.view.addSubview(clubsPic)
        }
    }
    override func setSuitIndicators() {
        spades = true
        hearts = true
        diamonds = true
        clubs = true
        
        spadesPic.removeFromSuperview()
        heartsPic.removeFromSuperview()
        diamondsPic.removeFromSuperview()
        clubsPic.removeFromSuperview()
    }
}
