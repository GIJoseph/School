//
//  ViewController.swift
//  Disperse
//
//  Created by Goergen, Joseph M on 8/23/17.
//  Copyright © 2017 Goergen, Joseph M. All rights reserved.
//

import UIKit
let TNDisperse = "Disperse"
let TNDisperse1Pile = "Disperse1Pile"
let TNDisperse4Pile = "Disperse4Pile"
let TNSubtractionNim = "Subtract"
let TNClassicNim = "Classic"

let games: [GameType] = [
    GameType(name: TNDisperse, rules: "Random collection of cards - remove between one and four cards (up to one card of each suit) on your turn as long as each of the cards that you want to remove is not covered by another card."),
    GameType(name: TNDisperse1Pile, rules: "1 pile of random cards - remove between one and four cards (up to one card of each suit) on your turn."),
    GameType(name: TNDisperse4Pile, rules: "4 piles of cards - remove one card from up to four piles (up to one card of each suit) on your turn."),
    GameType(name: TNSubtractionNim, rules: "1 pile of alternating suit cards - remove between one and four cards (up to one card of each suit) on your turn."),
    GameType(name: TNClassicNim, rules: "4 piles of cards - remove as many cards as you want from a single pile on your turn.")
]
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //self.presentDisperseViewController()
        self.presentGameTypeViewController()
        //self.presentDisperse1PileViewController()
        
    }
    func presentDisperseViewController() {
        let dvc: DisperseViewController = DisperseViewController()
        dvc.modalTransitionStyle = UIModalTransitionStyle.crossDissolve
        self.present(dvc, animated: true, completion: {
            () -> Void in
            dvc.enterNewGame()
        })
    }
    func presentGameTypeViewController(){
        let gtvc: GameTypeViewController = GameTypeViewController(games)
        self.present(gtvc, animated: true, completion: {
            () -> Void in
        })
    }
    func createNewGameWithGameType(_ game: String){
        
    }
    func presentDisperse1PileViewController() {
        let d1p: Disperse1PileViewController = Disperse1PileViewController()
        d1p.modalTransitionStyle = UIModalTransitionStyle.crossDissolve
        self.present(d1p, animated: true, completion: {
            () -> Void in
            d1p.enterNewGame()
        })
    }

}

