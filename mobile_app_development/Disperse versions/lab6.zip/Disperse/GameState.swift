//
//  GameState.swift
//  Disperse
//
//  Created by Tim Gegg-Harrison, Nicole Anderson on 7/27/16.
//  Copyright © 2016 TiNi Apps. All rights reserved.
//

import UIKit

class GameState {
    var board: [CardView]
    var blueTurn: Bool
    var user1Score: Int
    var user2Score: Int
    
    init() {
        board = [CardView]()
        blueTurn = true
        user1Score = 0
        user2Score = 0
    }
}
