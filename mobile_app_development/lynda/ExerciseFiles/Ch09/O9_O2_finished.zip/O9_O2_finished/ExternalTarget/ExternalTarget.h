
#import <UIKit/UIKit.h>

//! Project version number for ExternalTarget.
FOUNDATION_EXPORT double ExternalTargetVersionNumber;

//! Project version string for ExternalTarget.
FOUNDATION_EXPORT const unsigned char ExternalTargetVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ExternalTarget/PublicHeader.h>


