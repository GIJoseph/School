
import UIKit
import ExternalTarget

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let customStruct = CustomStruct(title: "CustomStruct")
        
        _ = customStruct.title
        
//        customStruct.title = "New Title"
        
        _ = ExternalCustomClass()
        
        _ = ExternalCustomStruct()
        
        let customClass = CustomClass()
        
        customClass.printTitle()
        
    }

}

class CustomClass : ExternalCustomClass {
    
    override func printTitle() {
        print(title, "(subclass of ExternalCustomClass")
    }
}
