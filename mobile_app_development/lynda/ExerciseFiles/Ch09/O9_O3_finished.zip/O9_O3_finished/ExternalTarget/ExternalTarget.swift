
open class ExternalCustomClass {
    
    public var title: String
        
    public init(title: String = "ExternalCustomClass") {
        self.title = title
    }
    
    open func printTitle() {
        print(title)
    }
}

public struct ExternalCustomStruct {
    
    var title = "ExternalCustomStruct"
    
    public init() { }
    
}
